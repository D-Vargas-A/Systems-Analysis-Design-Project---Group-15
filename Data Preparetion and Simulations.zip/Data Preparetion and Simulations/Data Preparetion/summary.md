# Resumen estadístico — FixTrain (cleaned)

- Filas: **510281**
- Columnas: **7**

## Columnas

- `model_code` — categórica; únicos: 9; missing: 0
- `start_year` — numérica; únicos: 7; missing: 0
- `start_month` — numérica; únicos: 12; missing: 0
- `product_code` — categórica; únicos: 31; missing: 0
- `end_month` — numérica; únicos: 12; missing: 0
- `end_year` — numérica; únicos: 5; missing: 0
- `target` — numérica; únicos: 12; missing: 0

## Estadísticos (numéricos)

|             |   count |        mean |      std |   min |   25% |   50% |   75% |   max |
|:------------|--------:|------------:|---------:|------:|------:|------:|------:|------:|
| start_year  |  510281 | 2006.23     | 0.791904 |  2003 |  2006 |  2006 |  2007 |  2009 |
| start_month |  510281 |    7.23928  | 3.05032  |     1 |     5 |     8 |    10 |    12 |
| end_year    |  510281 | 2007.62     | 1.02191  |  2005 |  2007 |  2008 |  2008 |  2009 |
| end_month   |  510281 |    6.72446  | 3.34166  |     1 |     4 |     7 |    10 |    12 |
| target      |  510281 |    0.005078 | 0.02174  |     0 |     0 |     0 |     0 |     1 |

## Top categorías (por columna categórica)

### `model_code`

- M2: 137190
- M6: 77175
- M4: 53914
- M7: 53649
- M8: 51693
- M3: 47505
- M9: 39339
- M5: 25614
- M1: 24202

### `product_code`

- P06: 95605
- P24: 80944
- P20: 68626
- P16: 63935
- P12: 44941
- P28: 22504
- P26: 19918
- P09: 16866
- P15: 16263
- P21: 14304
