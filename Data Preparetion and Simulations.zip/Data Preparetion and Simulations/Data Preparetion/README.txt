Proyecto ETL — Workshop 4 (Persona A: Julián)
============================================

Archivos RAW (dentro de data/raw/):
- FixTrain.csv
- RepairTrain.csv
- SaleTrain.csv
- Output_TargetID_Mapping.csv
- SampleSubmission.csv
- DesireOutputRef.csv

Archivo generado:
- data/cleaned/cleaned.csv  (resultado del proceso ETL)

Descripción del ETL aplicado (resumen):
1. Se cargó FixTrain.csv (sin encabezados originales).
2. Se renombraron las columnas a: model_code, product_code, start_date, end_date, target.
3. Se separaron las columnas de fecha en año y mes: start_year, start_month, end_year, end_month.
4. Se imputaron valores categóricos faltantes con 'Unknown' (si existían).
5. Se normalizó la columna `target` mediante Min-Max a rango [0,1].
6. Se guardó el dataset limpio en data/cleaned/cleaned.csv.

Cómo reproducir el ETL (NetBeans / Java):
- Asegúrate de tener el proyecto ETL en NetBeans con las clases `etl.CSVUtils` y `etl.DataPrep`.
- Coloca los archivos originales en: data/raw/
- Ejecuta la clase `etl.DataPrep` (Run File).
- El programa leerá data/raw/FixTrain.csv y generará data/cleaned/cleaned.csv.

Notas técnicas:
- Fechas: las cadenas 'YYYY/M' fueron separadas en año y mes (enteros).
- Target: normalizado; si necesitas el target original, ver el histórico generado por el código original.
- Si quieres que el target se deje sin normalizar (por ejemplo para análisis exploratorio), coméntalo en DataPrep.java.

Entregables generados automáticamente:
- notebooks/1_data_prep.ipynb  (explicación, código y gráficas reproducibles)
- data/summary.md
- data/README.txt

Preparado por: Julián Romero
