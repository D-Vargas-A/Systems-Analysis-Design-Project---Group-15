"""
Workshop 4 - Scenario 2: Event-Based Cellular Automata Simulation
PAKDD Cup 2014: ASUS Component Failure Spatial Modeling

Simula propagación de fallos en componentes ASUS usando CA
Modela interacciones espaciales y comportamientos emergentes
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.colors import ListedColormap
import seaborn as sns
import pandas as pd
import time
import os


class ASUSFailureCA:
    """
    Simulación de Autómatas Celulares para fallos en componentes ASUS
    Modela propagación espacial de fallos y patrones emergentes
    """

    def __init__(self, grid_size=50, random_state=42):
        """
        Inicializar simulación CA

        Parameters:
        -----------
        grid_size : int
            Tamaño del grid (grid_size x grid_size)
        random_state : int
            Semilla para reproducibilidad
        """
        self.grid_size = grid_size
        self.random_state = random_state
        self.grid = None
        self.history = []
        self.results = {}

        np.random.seed(random_state)

        # Crear carpetas
        os.makedirs('results/figures', exist_ok=True)

    def initialize_grid(self, initialization='component_clusters', density=0.3):
        """
        Inicializar grid de componentes

        States:
        0 = Componente funcionando
        1 = Componente con fallo

        Parameters:
        -----------
        initialization : str
            Método de inicialización
        density : float
            Densidad de componentes con fallo inicial
        """
        print(f"\n=== Initializing Component Grid ===")
        print(
            f"Grid size: {self.grid_size}x{self.grid_size} ({self.grid_size**2} components)")
        print(f"Initialization: {initialization}")

        self.grid = np.zeros((self.grid_size, self.grid_size), dtype=int)

        if initialization == 'random':
            # Distribución aleatoria de fallos
            self.grid = np.random.choice([0, 1], size=(self.grid_size, self.grid_size),
                                         p=[1-density, density])

        elif initialization == 'component_clusters':
            # Clusters de componentes (simula lotes de fabricación)
            n_clusters = 5
            cluster_size = self.grid_size // 5

            for _ in range(n_clusters):
                cx = np.random.randint(
                    cluster_size, self.grid_size - cluster_size)
                cy = np.random.randint(
                    cluster_size, self.grid_size - cluster_size)

                # Crear cluster con probabilidad de fallo más alta
                for i in range(-cluster_size//2, cluster_size//2):
                    for j in range(-cluster_size//2, cluster_size//2):
                        if 0 <= cx+i < self.grid_size and 0 <= cy+j < self.grid_size:
                            if np.random.random() < density * 1.5:
                                self.grid[cx+i, cy+j] = 1

        elif initialization == 'thermal_gradient':
            # Simula gradiente térmico (más fallos en zonas calientes)
            for i in range(self.grid_size):
                for j in range(self.grid_size):
                    # Más calor en el centro
                    dist_from_center = np.sqrt(
                        (i - self.grid_size/2)**2 + (j - self.grid_size/2)**2)
                    failure_prob = density * \
                        (1 + 0.5 * (1 - dist_from_center / (self.grid_size/2)))
                    if np.random.random() < failure_prob:
                        self.grid[i, j] = 1

        failed_components = np.sum(self.grid)
        print(
            f"Initial failed components: {failed_components} ({failed_components/(self.grid_size**2)*100:.1f}%)")

        self.history.append(self.grid.copy())

    def count_failed_neighbors(self, x, y):
        """
        Contar vecinos fallados (Moore neighborhood)

        Simula propagación de estrés térmico/eléctrico entre componentes
        """
        failed_neighbors = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                if i == 0 and j == 0:
                    continue
                nx = (x + i) % self.grid_size
                ny = (y + j) % self.grid_size
                failed_neighbors += self.grid[nx, ny]
        return failed_neighbors

    def apply_asus_failure_rules(self):
        """
        Aplicar reglas de propagación de fallos adaptadas a ASUS

        Reglas:
        - Componente funcionando con 3+ vecinos fallados → falla (sobrecarga)
        - Componente funcionando con 5+ vecinos fallados → falla seguro (cascada)
        - Componente fallado con 0-1 vecinos fallados → se repara (intervención)
        - Componente fallado con 2+ vecinos fallados → permanece fallado
        """
        new_grid = self.grid.copy()

        for x in range(self.grid_size):
            for y in range(self.grid_size):
                failed_neighbors = self.count_failed_neighbors(x, y)

                if self.grid[x, y] == 0:  # Componente funcionando
                    # Falla por propagación de estrés
                    if failed_neighbors >= 5:
                        new_grid[x, y] = 1  # Falla cascada
                    elif failed_neighbors >= 3:
                        if np.random.random() < 0.7:  # 70% prob
                            new_grid[x, y] = 1

                else:  # Componente fallado
                    # Reparación si no hay muchos fallos alrededor
                    if failed_neighbors <= 1:
                        if np.random.random() < 0.3:  # 30% prob reparación
                            new_grid[x, y] = 0

        self.grid = new_grid

    def run_simulation(self, iterations=100, save_frequency=10):
        """
        Ejecutar simulación CA

        Parameters:
        -----------
        iterations : int
            Número de iteraciones
        save_frequency : int
            Frecuencia de guardado de estados
        """
        print(f"\n=== Running CA Simulation ===")
        print(f"Iterations: {iterations}")

        start_time = time.time()

        failed_counts = []
        entropy_values = []
        cluster_sizes = []

        for iteration in range(iterations):
            self.apply_asus_failure_rules()

            # Métricas
            failed_count = np.sum(self.grid)
            failed_counts.append(failed_count)

            # Entropía
            if failed_count > 0 and failed_count < self.grid_size**2:
                p = failed_count / (self.grid_size ** 2)
                entropy = -p * np.log2(p) - (1-p) * np.log2(1-p)
            else:
                entropy = 0
            entropy_values.append(entropy)

            # Tamaño promedio de clusters
            cluster_size = self._calculate_cluster_size()
            cluster_sizes.append(cluster_size)

            # Guardar historial
            if iteration % save_frequency == 0:
                self.history.append(self.grid.copy())

            # Progreso
            if (iteration + 1) % 20 == 0:
                print(
                    f"  Iteration {iteration+1}/{iterations} - Failed: {failed_count} - Entropy: {entropy:.3f}")

        simulation_time = time.time() - start_time

        # Guardar resultados
        self.results['iterations'] = iterations
        self.results['simulation_time'] = simulation_time
        self.results['failed_counts'] = failed_counts
        self.results['entropy_values'] = entropy_values
        self.results['cluster_sizes'] = cluster_sizes
        self.results['final_failed'] = failed_counts[-1]

        print(f"\n✓ Simulation completed in {simulation_time:.2f}s")
        print(f"Final failed components: {failed_counts[-1]}")

    def _calculate_cluster_size(self):
        """
        Calcular tamaño promedio de clusters de fallos
        """
        labeled_grid, num_clusters = self._label_clusters()

        if num_clusters == 0:
            return 0

        cluster_sizes = []
        for cluster_id in range(1, num_clusters + 1):
            size = np.sum(labeled_grid == cluster_id)
            cluster_sizes.append(size)

        return np.mean(cluster_sizes) if cluster_sizes else 0

    def _label_clusters(self):
        """
        Etiquetar clusters de componentes fallados (BFS iterativo)
        Evita recursión para prevenir stack overflow
        """
        from collections import deque

        labeled = np.zeros_like(self.grid)
        current_label = 0

        def flood_fill_iterative(start_x, start_y, label):
            """Flood fill usando cola (evita recursión)"""
            queue = deque([(start_x, start_y)])

            while queue:
                x, y = queue.popleft()

                # Verificar límites
                if x < 0 or x >= self.grid_size or y < 0 or y >= self.grid_size:
                    continue

                # Verificar si ya fue etiquetado o si no es componente fallado
                if labeled[x, y] != 0 or self.grid[x, y] == 0:
                    continue

                # Etiquetar
                labeled[x, y] = label

                # Agregar vecinos a la cola (4-connectivity)
                queue.append((x+1, y))
                queue.append((x-1, y))
                queue.append((x, y+1))
                queue.append((x, y-1))

        # Recorrer el grid y etiquetar clusters
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                if self.grid[i, j] == 1 and labeled[i, j] == 0:
                    current_label += 1
                    flood_fill_iterative(i, j, current_label)

        return labeled, current_label

    def detect_patterns(self):
        """
        Detectar patrones emergentes
        """
        print("\n=== Pattern Detection ===")

        patterns = {
            'stable': 0,
            'oscillators': 0,
            'growing': 0,
            'shrinking': 0,
            'chaotic': 0
        }

        # Analizar últimos estados
        if len(self.history) >= 5:
            recent_failed = [np.sum(state) for state in self.history[-5:]]

            # Estabilidad
            if np.std(recent_failed) < 5:
                patterns['stable'] = 1
                print("✓ Stable pattern detected")

            # Oscilación
            elif len(set(recent_failed)) == 2:
                patterns['oscillators'] = 1
                print("✓ Oscillating pattern detected")

            # Crecimiento/decrecimiento
            elif recent_failed[-1] > recent_failed[0] * 1.2:
                patterns['growing'] = 1
                print("✓ Growing failure pattern")
            elif recent_failed[-1] < recent_failed[0] * 0.8:
                patterns['shrinking'] = 1
                print("✓ Shrinking failure pattern (recovery)")

            else:
                patterns['chaotic'] = 1
                print("✓ Chaotic pattern detected")

        # Detectar clusters
        labeled_grid, num_clusters = self._label_clusters()
        print(f"Number of failure clusters: {num_clusters}")

        self.results['patterns'] = patterns
        self.results['num_clusters'] = num_clusters

        return patterns

    def analyze_emergent_behavior(self):
        """
        Analizar comportamiento emergente y caos
        """
        print("\n=== Emergent Behavior Analysis ===")

        failed_counts = np.array(self.results['failed_counts'])
        entropy_values = np.array(self.results['entropy_values'])
        cluster_sizes = np.array(self.results['cluster_sizes'])

        # Punto de estabilización
        stabilization_point = None
        window = 10
        threshold = 5

        for i in range(window, len(failed_counts) - window):
            if np.std(failed_counts[i:i+window]) < threshold:
                stabilization_point = i
                break

        if stabilization_point:
            print(f"✓ System stabilized at iteration {stabilization_point}")
        else:
            print("✗ System did not stabilize")

        # Métrica de caos
        chaos_metric = np.std(failed_counts) / (np.mean(failed_counts) + 1e-10)

        # Cobertura espacial
        spatial_coverage = np.mean(failed_counts) / (self.grid_size ** 2)

        # Tamaño promedio de cluster
        avg_cluster_size = np.mean([cs for cs in cluster_sizes if cs > 0])

        # Guardar resultados
        self.results['stabilization_point'] = stabilization_point
        self.results['chaos_metric'] = chaos_metric
        self.results['spatial_coverage'] = spatial_coverage
        self.results['avg_cluster_size'] = avg_cluster_size
        self.results['avg_entropy'] = np.mean(entropy_values)

        print(f"Chaos Metric: {chaos_metric:.4f}")
        print(f"Spatial Coverage: {spatial_coverage:.4f}")
        print(f"Avg Cluster Size: {avg_cluster_size:.2f} components")
        print(f"Average Entropy: {np.mean(entropy_values):.4f}")

        # Clasificar nivel de caos
        if chaos_metric < 0.2:
            chaos_level = "Low"
        elif chaos_metric < 0.5:
            chaos_level = "Medium"
        else:
            chaos_level = "High"

        print(f"Chaos Level: {chaos_level}")

        return self.results

    def visualize_evolution(self):
        """
        Visualizar evolución del sistema
        """
        print("\n=== Generating Visualizations ===")

        fig, axes = plt.subplots(2, 2, figsize=(15, 13))
        fig.suptitle('PAKDD Cup 2014 - CA Simulation: ASUS Component Failures',
                     fontsize=16, fontweight='bold')

        # 1. Estado inicial y final
        ax1 = axes[0, 0]
        cmap = ListedColormap(['#22c55e', '#dc2626'])  # Verde: OK, Rojo: Fallo
        im1 = ax1.imshow(self.history[0], cmap=cmap, interpolation='nearest')
        ax1.set_title(
            f'Initial State (t=0)\n{np.sum(self.history[0])} failed components')
        ax1.axis('off')
        plt.colorbar(im1, ax=ax1, ticks=[0, 1], label='0=OK, 1=Failed')

        ax2 = axes[0, 1]
        im2 = ax2.imshow(self.history[-1], cmap=cmap, interpolation='nearest')
        ax2.set_title(
            f'Final State (t={self.results["iterations"]})\n{np.sum(self.history[-1])} failed components')
        ax2.axis('off')
        plt.colorbar(im2, ax=ax2, ticks=[0, 1], label='0=OK, 1=Failed')

        # 2. Dinámica de fallos
        ax3 = axes[1, 0]
        failed_counts = self.results['failed_counts']
        ax3.plot(failed_counts, linewidth=2,
                 color='#dc2626', label='Failed Components')
        ax3.axhline(y=np.mean(failed_counts), color='#2563eb', linestyle='--',
                    label=f'Mean: {np.mean(failed_counts):.0f}', alpha=0.7)
        if self.results['stabilization_point']:
            ax3.axvline(x=self.results['stabilization_point'], color='#16a34a',
                        linestyle='--', label='Stabilization', alpha=0.7)
        ax3.set_xlabel('Iteration')
        ax3.set_ylabel('Failed Components')
        ax3.set_title('Component Failure Dynamics')
        ax3.legend()
        ax3.grid(True, alpha=0.3)

        # 3. Entropía y tamaño de clusters
        ax4 = axes[1, 1]
        ax4_twin = ax4.twinx()

        entropy_values = self.results['entropy_values']
        cluster_sizes = self.results['cluster_sizes']

        line1 = ax4.plot(entropy_values, linewidth=2,
                         color='#f59e0b', label='Entropy')
        ax4.set_xlabel('Iteration')
        ax4.set_ylabel('Entropy', color='#f59e0b')
        ax4.tick_params(axis='y', labelcolor='#f59e0b')

        line2 = ax4_twin.plot(cluster_sizes, linewidth=2,
                              color='#8b5cf6', label='Avg Cluster Size')
        ax4_twin.set_ylabel('Avg Cluster Size', color='#8b5cf6')
        ax4_twin.tick_params(axis='y', labelcolor='#8b5cf6')

        ax4.set_title('System Entropy and Clustering')
        ax4.grid(True, alpha=0.3)

        # Combinar leyendas
        lines = line1 + line2
        labels = [l.get_label() for l in lines]
        ax4.legend(lines, labels, loc='upper left')

        plt.tight_layout()
        plt.savefig('results/figures/ca_simulation.png',
                    dpi=300, bbox_inches='tight')
        print("✓ Visualization saved: results/figures/ca_simulation.png")

        return fig

    def generate_report(self):
        """
        Generar reporte de simulación
        """
        patterns = self.results.get('patterns', {})

        report = f"""
{'='*70}
CA SIMULATION REPORT - PAKDD CUP 2014
ASUS Component Failure Spatial Modeling
{'='*70}

1. SIMULATION CONFIGURATION
   - Grid Size: {self.grid_size}x{self.grid_size}
   - Total Components: {self.grid_size ** 2}
   - Iterations: {self.results['iterations']}
   - Simulation Time: {self.results['simulation_time']:.2f} seconds

2. FAILURE DYNAMICS
   - Initial Failed: {self.results['failed_counts'][0]}
   - Final Failed: {self.results['final_failed']}
   - Average Failed: {np.mean(self.results['failed_counts']):.0f}
   - Std Deviation: {np.std(self.results['failed_counts']):.2f}

3. EMERGENT PATTERNS
   - Stable Patterns: {'Yes' if patterns.get('stable') else 'No'}
   - Oscillating: {'Yes' if patterns.get('oscillators') else 'No'}
   - Growing Failures: {'Yes' if patterns.get('growing') else 'No'}
   - Shrinking (Recovery): {'Yes' if patterns.get('shrinking') else 'No'}
   - Chaotic Behavior: {'Yes' if patterns.get('chaotic') else 'No'}
   - Failure Clusters: {self.results['num_clusters']}

4. CHAOS & COMPLEXITY ANALYSIS
   - Stabilization Point: {self.results['stabilization_point'] if self.results['stabilization_point'] else 'Not reached'}
   - Chaos Metric: {self.results['chaos_metric']:.4f}
   - Spatial Coverage: {self.results['spatial_coverage']*100:.2f}%
   - Avg Cluster Size: {self.results['avg_cluster_size']:.2f} components
   - Average Entropy: {self.results['avg_entropy']:.4f}

5. SYSTEM BEHAVIOR CLASSIFICATION
   - Complexity Level: {'High' if self.results['chaos_metric'] > 0.5 else 'Medium' if self.results['chaos_metric'] > 0.2 else 'Low'}
   - Stability: {'Achieved' if self.results['stabilization_point'] else 'Not achieved'}
   - Clustering: {'Strong' if self.results['avg_cluster_size'] > 10 else 'Moderate' if self.results['avg_cluster_size'] > 5 else 'Weak'}

6. KEY FINDINGS FOR ASUS
   - Failure propagation shows {'rapid' if self.results['chaos_metric'] > 0.5 else 'controlled'} spatial spread
   - Component clusters suggest {'manufacturing batch' if self.results['num_clusters'] > 3 else 'isolated'} failure patterns
   - System {'exhibits' if not self.results['stabilization_point'] else 'reaches'} equilibrium
   - Spatial coverage indicates {'high' if self.results['spatial_coverage'] > 0.3 else 'moderate'} failure density

7. ARCHITECTURAL IMPLICATIONS
   - {'Implement' if self.results['chaos_metric'] > 0.5 else 'Maintain'} spatial redundancy in component layout
   - Failure cascades suggest need for thermal isolation
   - Cluster patterns indicate quality control at manufacturing level
   - {'Proactive' if self.results['chaos_metric'] > 0.5 else 'Reactive'} maintenance strategy recommended

{'='*70}
"""

        print(report)

        with open('results/ca_simulation_report.txt', 'w') as f:
            f.write(report)

        print("\n✓ Report saved: results/ca_simulation_report.txt")

        return report


def main():
    """
    Función principal
    """
    print("="*70)
    print("WORKSHOP 4 - CA SIMULATION")
    print("PAKDD Cup 2014: ASUS Component Failure Modeling")
    print("="*70)

    # Inicializar
    ca = ASUSFailureCA(grid_size=50, random_state=42)

    # 1. Inicializar grid
    ca.initialize_grid(initialization='component_clusters', density=0.25)

    # 2. Ejecutar simulación
    ca.run_simulation(iterations=100, save_frequency=10)

    # 3. Detectar patrones
    ca.detect_patterns()

    # 4. Analizar comportamiento emergente
    ca.analyze_emergent_behavior()

    # 5. Visualizar
    ca.visualize_evolution()

    # 6. Generar reporte
    ca.generate_report()

    print("\n" + "="*70)
    print("✓ SIMULATION COMPLETED SUCCESSFULLY!")
    print("="*70)
    print("\nGenerated files:")
    print("  - results/ca_simulation_report.txt")
    print("  - results/figures/ca_simulation.png")


if __name__ == "__main__":
    main()
