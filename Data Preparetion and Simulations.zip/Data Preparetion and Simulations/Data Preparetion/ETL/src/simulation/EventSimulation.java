package simulation;

import java.util.Random;

/**
 * Automaton-based simulation with chaotic dynamics.
 * Modeled aspects:
 * - transitions sensitive to randomness,
 * - increasing perturbations,
 * - feedback loops,
 * - unstable states similar to chaotic systems.
 */
public class EventSimulation {

    enum State { NORMAL, HIGH_LOAD, BAD_DATA, PARTIAL_FAILURE, RECOVERY }

    private State state = State.NORMAL;
    private Random r = new Random();

    // Chaos level — increases with each cycle
    private double chaosLevel = 0.02;

    // Chaotic perturbation
    public boolean chaoticEvent(double probability) {
        // chaos amplifies probabilities
        double p = probability + chaosLevel;
        return r.nextDouble() < p;
    }

    public void nextCycle() {

        System.out.println("Current state: " + state);

        switch (state) {

            case NORMAL:
                // small perturbations can cause bifurcations
                if (chaoticEvent(0.05)) state = State.HIGH_LOAD;
                if (chaoticEvent(0.03)) state = State.BAD_DATA;
                break;

            case HIGH_LOAD:
                if (chaoticEvent(0.15)) state = State.PARTIAL_FAILURE;
                if (chaoticEvent(0.30)) state = State.RECOVERY;
                break;

            case BAD_DATA:
                // incorrect values can escalate to major failures
                if (chaoticEvent(0.25)) state = State.PARTIAL_FAILURE;
                if (chaoticEvent(0.40)) state = State.RECOVERY;
                break;

            case PARTIAL_FAILURE:
                // feedback: the system attempts to recover
                if (chaoticEvent(0.60)) state = State.RECOVERY;
                break;

            case RECOVERY:
                state = State.NORMAL;
                break;
        }

        // Every cycle chaos grows a little → non-linear dynamics
        chaosLevel += 0.005;
    }

    public static void main(String[] args) {

        EventSimulation sim = new EventSimulation();

        System.out.println("\n=== EVENT SIMULATION WITH CHAOS THEORY ===\n");

        // run for 30 cycles
        for (int i = 0; i < 30; i++) {
            System.out.println("---- Cycle " + i + " ----");
            sim.nextCycle();
        }
    }
}