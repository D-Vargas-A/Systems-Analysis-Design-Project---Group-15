package simulation;

import etl.CSVUtils;
import java.util.*;
import weka.classifiers.functions.Logistic;
import weka.core.*;

/**
 * Data-driven simulation with chaotic perturbations.
 * The system tests:
 * - Sensitivity to small initial changes (chaos theory).
 * - Increasing perturbations in input values.
 * - Feedback: if performance drops, the model retrains.
 */
public class MLSimulation {

    // ------------------------------------------------------
    // Add controlled noise: simulates chaos and system drift
    // ------------------------------------------------------
    public static double addChaos(double value, double noiseLevel) {
        Random r = new Random();

        // tiny perturbation: sensitivity to initial conditions
        double tinyPerturbation = (r.nextDouble() - 0.5) * noiseLevel;

        // butterfly effect: small perturbations can amplify error
        return value + tinyPerturbation;
    }

    // ------------------------------------------------------
    // Apply noise to the complete dataset
    // ------------------------------------------------------
    public static Instances applyChaos(Instances data, double noiseLevel) {
        Instances noisy = new Instances(data);

        for (int i = 0; i < noisy.size(); i++) {
            Instance inst = noisy.get(i);

            for (int j = 0; j < inst.numAttributes(); j++) {
                if (j == noisy.classIndex()) continue; // target is not touched

                double v = inst.value(j);
                inst.setValue(j, addChaos(v, noiseLevel)); 
            }
        }
        return noisy;
    }

    // ------------------------------------------------------
    // MAIN
    // ------------------------------------------------------
    public static void main(String[] args) throws Exception {

        System.out.println("\n=== ML SIMULATION WITH CHAOS THEORY ===");

        List<Map<String, String>> data =
                CSVUtils.loadCSV("data/cleaned/cleaned.csv");

        // Create attributes
        ArrayList<Attribute> attrs = new ArrayList<>();
        attrs.add(new Attribute("model_code"));
        attrs.add(new Attribute("product_code"));
        attrs.add(new Attribute("start_year"));
        attrs.add(new Attribute("start_month"));
        attrs.add(new Attribute("end_year"));
        attrs.add(new Attribute("end_month"));
        attrs.add(new Attribute("target"));

        Instances dataset = new Instances("notebooks", attrs, data.size());
        dataset.setClassIndex(dataset.numAttributes() - 1);

        // Convert rows
        for (Map<String, String> row : data) {
            double[] vals = new double[dataset.numAttributes()];
            int i = 0;
            for (Attribute a : attrs) {
                vals[i] = Double.parseDouble(row.get(a.name()));
                i++;
            }
            dataset.add(new DenseInstance(1.0, vals));
        }

        // Split
        int trainSize = (int) (dataset.size() * 0.7);
        Instances train = new Instances(dataset, 0, trainSize);
        Instances test = new Instances(dataset, trainSize, dataset.size() - trainSize);

        Logistic model = new Logistic();
        model.buildClassifier(train);

        double baselineAccuracy = evaluate(model, test);
        System.out.println("Initial Accuracy: " + baselineAccuracy);

        // ============================================================
        // CHAOS SIMULATION: perturbations are increased in each iteration
        // ============================================================
        for (double noise = 0.01; noise <= 0.1; noise += 0.02) {

            System.out.println("\n>> Applied noise: " + noise);

            // Apply chaos to the test set
            Instances chaoticTest = applyChaos(test, noise);

            double accuracy = evaluate(model, chaoticTest);
            System.out.println("Accuracy with chaos: " + accuracy);

            // SYSTEM FEEDBACK
            // If precision drops below 75% of baseline -> retrain
            if (accuracy < baselineAccuracy * 0.75) {
                System.out.println("⚠ Accuracy dropped too much. Retraining (feedback loop).");
                model.buildClassifier(train);
            }
        }
    }

    // Model evaluation
    public static double evaluate(Logistic model, Instances test) throws Exception {
        double correct = 0;

        for (int i = 0; i < test.size(); i++) {
            double pred = model.classifyInstance(test.get(i));
            double real = test.get(i).classValue();
            if (Math.abs(pred - real) < 0.25) correct++;
        }
        return correct / test.size();
    }
}