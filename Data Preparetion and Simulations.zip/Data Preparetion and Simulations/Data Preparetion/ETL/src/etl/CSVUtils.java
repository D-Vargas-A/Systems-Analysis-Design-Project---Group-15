package etl;

import java.io.*;
import java.util.*;

public class CSVUtils {

    // Leer CSV sin encabezados
    public static List<Map<String, String>> loadCSV(String path) {

        List<Map<String, String>> data = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {

            String line;
            while ((line = br.readLine()) != null) {
                String[] cols = line.split(",");

                Map<String, String> row = new HashMap<>();

                // Guardar con columnas numéricas 0,1,2,3,4
                for (int i = 0; i < cols.length; i++) {
                    row.put(String.valueOf(i), cols[i]);
                }
                data.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    // Guardar CSV limpio
    public static void saveCSV(List<Map<String, String>> data, String path) {

        if (data.isEmpty()) return;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {

            // Encabezados
            Set<String> columns = data.get(0).keySet();
            writer.write(String.join(",", columns));
            writer.newLine();

            // Filas
            for (Map<String, String> row : data) {
                List<String> vals = new ArrayList<>();
                for (String col : columns) vals.add(row.get(col));
                writer.write(String.join(",", vals));
                writer.newLine();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
