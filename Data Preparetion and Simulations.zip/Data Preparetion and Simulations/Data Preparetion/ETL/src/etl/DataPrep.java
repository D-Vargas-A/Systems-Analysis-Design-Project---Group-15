package etl;

import java.util.*;

public class DataPrep {

    // ==========================
    // CONTAR VALORES FALTANTES
    // ==========================
    public static Map<String, Integer> countMissing(List<Map<String, String>> data) {
        Map<String, Integer> missing = new HashMap<>();

        if (data.isEmpty()) return missing;

        Set<String> columns = data.get(0).keySet();
        for (String col : columns) missing.put(col, 0);

        for (Map<String, String> row : data) {
            for (String col : columns) {
                if (row.get(col) == null || row.get(col).trim().isEmpty()) {
                    missing.put(col, missing.get(col) + 1);
                }
            }
        }
        return missing;
    }

    // ==========================
    // IMPUTAR CATEGÓRICOS
    // ==========================
    public static void fillMissingCategorical(List<Map<String, String>> data, String col) {
        for (Map<String, String> row : data) {
            if (row.get(col) == null || row.get(col).trim().isEmpty()) {
                row.put(col, "Unknown");
            }
        }
    }

    // ==========================
    // NORMALIZACIÓN MIN-MAX
    // ==========================
    public static void normalizeColumn(List<Map<String, String>> data, String col) {
        List<Double> nums = new ArrayList<>();

        for (Map<String, String> row : data) {
            nums.add(Double.parseDouble(row.get(col)));
        }

        double min = Collections.min(nums);
        double max = Collections.max(nums);

        for (Map<String, String> row : data) {
            double v = Double.parseDouble(row.get(col));
            double norm = (v - min) / (max - min);
            row.put(col, String.valueOf(norm));
        }
    }

    // ==========================
    // SEPARAR FECHAS start_date y end_date
    // ==========================
    public static void splitDate(List<Map<String, String>> data, String col, String yearName, String monthName) {
        for (Map<String, String> row : data) {
            String value = row.get(col);
            if (value == null || !value.contains("/")) {
                row.put(yearName, "0");
                row.put(monthName, "0");
                continue;
            }

            try {
                String[] parts = value.split("/");
                row.put(yearName, parts[0]);
                row.put(monthName, parts[1]);
            } catch (Exception e) {
                row.put(yearName, "0");
                row.put(monthName, "0");
            }
        }
    }

    // ==========================
    // MAIN
    // ==========================
    public static void main(String[] args) {

        System.out.println("Cargando dataset FixTrain.csv...");

        // El archivo real
        List<Map<String, String>> data =
                CSVUtils.loadCSV("data/raw/FixTrain.csv");

        System.out.println("Filas cargadas: " + data.size());

        // ============================================
        // 1. Renombrar columnas (porque FixTrain NO trae encabezado)
        // ============================================
        // Los nombres reales serán:
        // model_code, product_code, start_date, end_date, target

        for (Map<String, String> row : data) {
            row.put("model_code", row.remove("0"));
            row.put("product_code", row.remove("1"));
            row.put("start_date", row.remove("2"));
            row.put("end_date", row.remove("3"));
            row.put("target", row.remove("4"));
        }

        // ============================================
        // 2. Contar missing
        // ============================================
        System.out.println("\nValores faltantes:");
        Map<String, Integer> miss = countMissing(data);
        miss.forEach((k, v) -> System.out.println(k + ": " + v));

        // ============================================
        // 3. Imputación categórica
        // ============================================
        fillMissingCategorical(data, "model_code");
        fillMissingCategorical(data, "product_code");

        // ============================================
        // 4. Convertir fechas — Opción B aplicada
        // ============================================
        splitDate(data, "start_date", "start_year", "start_month");
        splitDate(data, "end_date", "end_year", "end_month");

        // Ya no necesitamos las columnas originales:
        for (Map<String, String> row : data) {
            row.remove("start_date");
            row.remove("end_date");
        }

        // ============================================
        // 5. Normalizar TARGET
        // ============================================
        normalizeColumn(data, "target");

        // ============================================
        // 6. Guardar CLEANED
        // ============================================
        System.out.println("\nGenerando cleaned.csv...");
        CSVUtils.saveCSV(data, "data/cleaned/cleaned.csv");

        System.out.println("✔ ETL completado con éxito.");
    }
}
